//
// Created by phatt on 10/18/25.
//

#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H



class FrameBuffer {

};



#endif //FRAMEBUFFER_H
