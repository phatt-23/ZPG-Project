
#pragma once

#include "Transform/Transform.h"
namespace ZPG {

class DynamicTransform : public Transform {
public:
    DynamicTransform() {}
    virtual ~DynamicTransform() override {}
protected:
};

}
