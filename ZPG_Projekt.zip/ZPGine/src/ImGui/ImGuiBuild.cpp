//
// Created by phatt on 2/10/25.
//

// #include <imgui/backends/imgui_impl_opengl3_loader.h>
// #include <imgui/backends/imgui_impl_opengl3.cpp>
// #include <imgui/backends/imgui_impl_glfw.cpp>
//
#include "implot/implot.h"
#include "implot/implot_internal.h"

#include "implot/implot.cpp"
#include "implot/implot_items.cpp"
